// JavaScript Document
DD_belatedPNG.fix('div,ur,ol,li,dt,dd,dl,sapan,img,a,em,strong,h1,h2,h3,h4,h5,h6,p,td');
DD_belatedPNG.fix('button');
DD_belatedPNG.fix('a');
DD_belatedPNG.fix('h1');
DD_belatedPNG.fix('h5');
DD_belatedPNG.fix('form');
DD_belatedPNG.fix('p img');
DD_belatedPNG.fix('a img');
DD_belatedPNG.fix('img');
DD_belatedPNG.fix('input');
DD_belatedPNG.fix('li');
DD_belatedPNG.fix('td');
DD_belatedPNG.fix('span');
DD_belatedPNG.fix('table tr td');
