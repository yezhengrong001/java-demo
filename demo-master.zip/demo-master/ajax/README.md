### 案例2：通过Ajax实现动态无刷新页面进行查询/添加操作。
#### 涉及技术点：
1. HTML+CSS简单布局
2. Ajax + JSON 实现页面查询/添加操作。
3. jQuery基础运用
4. Ajax跨域解决方案（JSONP + CORS）


